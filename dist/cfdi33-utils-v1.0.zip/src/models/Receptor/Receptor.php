<?php

namespace rdomenzain\cfdi\utils\models\Receptor;

class Receptor
{

    public $Rfc;
    public $Nombre;
    public $ResidenciaFiscal;
    public $NumRegIdTrib;
    public $UsoCFDI;
}
