<?php

namespace rdomenzain\cfdi\utils\models\Conceptos;

class Traslados
{
    /* @var $Traslado Traslado */
    public $Traslado;
}
