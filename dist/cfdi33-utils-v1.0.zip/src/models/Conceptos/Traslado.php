<?php

namespace rdomenzain\cfdi\utils\models\Conceptos;

class Traslado
{

    public $Base;
    public $Impuesto;
    public $TipoFactor;
    public $TasaOCuota;
    public $Importe;
}
