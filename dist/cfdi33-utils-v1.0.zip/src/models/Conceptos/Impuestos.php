<?php

namespace rdomenzain\cfdi\utils\models\Conceptos;

class Impuestos
{
    /* @var $Traslados Traslados */
    public $Traslados;
    /* @var $Retenciones Retenciones */
    public $Retenciones;
}
