<?php

namespace rdomenzain\cfdi\utils\models\Conceptos;

class Parte
{

    public $ClaveProdServ;
    public $NoIdentificacion;
    public $Cantidad;
    public $Unidad;
    public $Descripcion;
    public $ValorUnitario;
    public $Importe;
    /* @var $InformacionAduanera InformacionAduanera */
    public $InformacionAduanera;
}
