<?php

namespace rdomenzain\cfdi\utils\models\Conceptos;

class CuentaPredial
{
    public $Numero;
}
