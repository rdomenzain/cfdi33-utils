<?php

namespace rdomenzain\cfdi\utils\models\Conceptos;

class InformacionAduanera
{
    public $NumeroPedimento;
}
