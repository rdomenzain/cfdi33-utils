<?php

namespace rdomenzain\cfdi\utils\models\Conceptos;

class Concepto
{

    public $ClaveProdServ;
    public $NoIdentificacion;
    public $Cantidad;
    public $ClaveUnidad;
    public $Unidad;
    public $Descripcion;
    public $ValorUnitario;
    public $Importe;
    public $Descuento;
    /* @var $Impuestos Impuestos */
    public $Impuestos;
    /* @var $InformacionAduanera InformacionAduanera */
    public $InformacionAduanera;
    /* @var $CuentaPredial CuentaPredial */
    public $CuentaPredial;
    /* @var $ComplementoConcepto ComplementoConcepto */
    public $ComplementoConcepto;
    /* @var $Parte Parte */
    public $Parte;
}
