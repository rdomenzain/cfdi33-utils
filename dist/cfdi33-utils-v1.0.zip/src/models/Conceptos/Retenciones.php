<?php

namespace rdomenzain\cfdi\utils\models\Conceptos;

class Retenciones
{

    public $Retencion;
}
