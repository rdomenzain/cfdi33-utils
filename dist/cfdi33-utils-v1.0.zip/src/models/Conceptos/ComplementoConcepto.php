<?php

class ComplementoConcepto
{ }
