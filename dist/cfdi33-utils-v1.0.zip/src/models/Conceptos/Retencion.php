<?php

namespace rdomenzain\cfdi\utils\models\Conceptos;

class Retencion
{

    public $Base;
    public $Impuesto;
    public $TipoFactor;
    public $TasaOCuota;
    public $Importe;
}
