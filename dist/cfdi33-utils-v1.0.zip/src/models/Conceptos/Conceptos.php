<?php

namespace rdomenzain\cfdi\utils\models\Conceptos;

class Conceptos
{
    /* @var $Concepto Concepto */
    public $Concepto;
}
