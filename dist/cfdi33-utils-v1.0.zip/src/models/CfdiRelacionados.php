<?php

namespace rdomenzain\cfdi\utils\models;

class CfdiRelacionados
{

    public $TipoRelacion;
    /* @var $CfdiRelacionado CfdiRelacionado */
    public $CfdiRelacionado;
}
