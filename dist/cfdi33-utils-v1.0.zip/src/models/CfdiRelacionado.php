<?php

namespace rdomenzain\cfdi\utils\models;

class CfdiRelacionado
{

    public $UUID;
}
