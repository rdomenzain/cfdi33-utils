<?php

namespace rdomenzain\cfdi\utils\models\LeyendasFiscales;

class Leyenda
{

    public $disposicionFiscal;
    public $norma;
    public $textoLeyenda;
}
