<?php

namespace rdomenzain\cfdi\utils\models\LeyendasFiscales;

class LeyendasFiscales
{

    public $version;
    /* @var $Leyenda Leyenda */
    public $Leyenda;
}
