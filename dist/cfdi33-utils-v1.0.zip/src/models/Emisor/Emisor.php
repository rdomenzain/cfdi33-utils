<?php

namespace rdomenzain\cfdi\utils\models\Emisor;

class Emisor
{
    public $Rfc;
    public $Nombre;
    public $RegimenFiscal;
}
