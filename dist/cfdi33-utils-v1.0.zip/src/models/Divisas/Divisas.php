<?php

namespace rdomenzain\cfdi\utils\models\Divisas;

class Divisas
{

    public $version;
    public $tipoOperacion;
}
