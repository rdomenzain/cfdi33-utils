<?php

namespace rdomenzain\cfdi\utils\models\ImpuestosLocales;

class RetencionesLocales
{

    public $ImpLocRetenido;
    public $TasadeRetencion;
    public $Importe;
}
