<?php

namespace rdomenzain\cfdi\utils\models\ImpuestosLocales;

class ImpuestosLocales
{

    public $version;
    public $TotaldeRetenciones;
    public $TotaldeTraslados;
    /* @var $RetencionesLocales RetencionesLocales */
    public $RetencionesLocales;
    /* @var $TrasladosLocales TrasladosLocales */
    public $TrasladosLocales;
}
