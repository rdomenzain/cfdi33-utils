<?php

namespace rdomenzain\cfdi\utils\models\ImpuestosLocales;

class TrasladosLocales
{

    public $ImpLocTrasladado;
    public $TasadeTraslado;
    public $Importe;
}
