<?php

namespace rdomenzain\cfdi\utils\models\Donatarias;

class Donatarias
{

    public $version;
    public $noAutorizacion;
    public $fechaAutorizacion;
    public $leyenda;
}
