<?php

namespace rdomenzain\cfdi\utils\models\Impuestos;

class ImpImpuestos
{

    /* @var $Retenciones ImpRetenciones */
    public $Retenciones;
    /* @var $Traslados ImpTraslados */
    public $Traslados;
    public $TotalImpuestosRetenidos;
    public $TotalImpuestosTrasladados;
}
