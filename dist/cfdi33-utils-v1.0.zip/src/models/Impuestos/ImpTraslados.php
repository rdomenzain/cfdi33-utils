<?php

namespace rdomenzain\cfdi\utils\models\Impuestos;

class ImpTraslados
{

    /* @var $Traslado ImpTraslado */
    public $Traslado;
}
