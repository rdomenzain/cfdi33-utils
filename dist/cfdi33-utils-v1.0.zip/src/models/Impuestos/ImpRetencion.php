<?php

namespace rdomenzain\cfdi\utils\models\Impuestos;

class ImpRetencion
{

    public $Impuesto;
    public $Importe;
}
