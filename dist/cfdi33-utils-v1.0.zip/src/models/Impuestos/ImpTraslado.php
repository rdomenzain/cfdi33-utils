<?php

namespace rdomenzain\cfdi\utils\models\Impuestos;

class ImpTraslado
{

    public $Impuesto;
    public $TipoFactor;
    public $TasaOCuota;
    public $Importe;
}
