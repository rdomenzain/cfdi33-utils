<?php

namespace rdomenzain\cfdi\utils\models\Impuestos;

class ImpRetenciones
{

    /* @var $Retencion ImpRetencion */
    public $Retencion;
}
