<?php

namespace rdomenzain\cfdi\utils\models\ComplementoSPEI;

class Complemento_SPEI
{

    /* @var $SPEI_Tercero SPEI_Tercero */
    public $SPEI_Tercero;
}
