<?php

namespace rdomenzain\cfdi\utils\models\ComplementoSPEI;

class Ordenante
{

    public $BancoEmisor;
    public $Nombre;
    public $TipoCuenta;
    public $Cuenta;
    public $RFC;
}
