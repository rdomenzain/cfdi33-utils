<?php

namespace rdomenzain\cfdi\utils\models\ComplementoSPEI;

class Beneficiario
{

    public $BancoReceptor;
    public $Nombre;
    public $TipoCuenta;
    public $Cuenta;
    public $RFC;
    public $Concepto;
    public $IVA;
    public $MontoPago;
}
