<?php

namespace rdomenzain\cfdi\utils\models\ecc11;

class EstadoDeCuentaCombustible
{

    public $Version;
    public $TipoOperacion;
    public $NumeroDeCuenta;
    public $SubTotal;
    public $Total;
    /* @var $ConceptosECC ConceptosECC */
    public $ConceptosECC;
}
