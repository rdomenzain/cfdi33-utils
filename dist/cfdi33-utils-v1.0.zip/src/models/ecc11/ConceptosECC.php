<?php

namespace rdomenzain\cfdi\utils\models\ecc11;

class ConceptosECC
{

    /* @var $ConceptoEstadoDeCuentaCombustible ConceptoEstadoDeCuentaCombustible */
    public $ConceptoEstadoDeCuentaCombustible;
}
