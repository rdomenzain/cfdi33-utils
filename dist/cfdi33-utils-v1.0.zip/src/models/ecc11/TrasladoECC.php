<?php

namespace rdomenzain\cfdi\utils\models\ecc11;

class TrasladoECC
{
    public $Impuesto;
    public $TasaoCuota;
    public $Importe;
}
