<?php

namespace rdomenzain\cfdi\utils\models\ecc11;

class TrasladosECC
{

    /* @var $TrasladoECC TrasladoECC */
    public $TrasladoECC;
}
