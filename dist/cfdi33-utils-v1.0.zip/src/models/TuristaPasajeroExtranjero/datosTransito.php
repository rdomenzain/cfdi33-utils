<?php

namespace rdomenzain\cfdi\utils\models\TuristaPasajeroExtranjero;

class datosTransito
{

    public $Via;
    public $TipoId;
    public $NumeroId;
    public $Nacionalidad;
    public $EmpresaTransporte;
    public $IdTransporte;
}
