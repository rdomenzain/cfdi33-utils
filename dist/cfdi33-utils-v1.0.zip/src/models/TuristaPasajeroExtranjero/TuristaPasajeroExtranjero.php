<?php

namespace rdomenzain\cfdi\utils\models\TuristaPasajeroExtranjero;

class TuristaPasajeroExtranjero
{

    public $version;
    public $fechadeTransito;
    public $tipoTransito;
    /* @var $datosTransito datosTransito */
    public $datosTransito;
}
