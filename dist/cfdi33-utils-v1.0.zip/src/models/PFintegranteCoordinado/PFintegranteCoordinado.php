<?php

namespace rdomenzain\cfdi\utils\models\PFintegranteCoordinado;

class PFintegranteCoordinado
{

    public $version;
    public $ClaveVehicular;
    public $Placa;
    public $RFCPF;
}
