<?php

namespace rdomenzain\cfdi\utils\models;

class Addenda
{ }
